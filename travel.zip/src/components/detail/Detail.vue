<template>
    <div class="detail">
        详细内容部分
    </div>
</template>
<script>
export default {
    name:'Detail'
}
</script>
<style lang="less" scoped>

</style>
